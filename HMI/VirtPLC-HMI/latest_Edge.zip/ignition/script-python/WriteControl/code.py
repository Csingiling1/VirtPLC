if not initialChange:
    import system
    path = event.getTagPath().toString()
    val = newValue.getValue()
    
    # Determine device code
    dev = ""
    if "Conveyor1" in path: dev = "c1"
    elif "Conveyor2" in path: dev = "c2"
    elif "ComponentPlacer1" in path: dev = "p1"
    
    # Send Command to Node-RED
    if dev:
        url = "http://localhost:1880/api/control"
        body = {"device": dev, "value": val}
        try:
            system.net.httpPost(url, contentType="application/json", postData=system.util.jsonEncode(body))
        except:
            pass